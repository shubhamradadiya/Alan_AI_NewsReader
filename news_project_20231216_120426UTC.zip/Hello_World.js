intent('what does this app do?', 'what can i do here?',
      reply('This is a news project.'));  


intent('Who make this project?',
          reply('By MR.SHUBHAM RADADIYA'))

// 
// intent('Start a command' , (p)=>{
//     p.play( { command: ' testCommand'}) 
// })

const API_KEY = '4a69b3021b6f453caf561c86a7caa9f2';
let saveArticles = [];

intent('Give me the news from $(source* (.*))', (p) => {
    let source = p.source.value.toLowerCase().split(" ").join("-"); // Modify source to lowercase and replace spaces with dashes
    let NEWS_API_URL = `https://newsapi.org/v2/top-headlines?sources=${source}&apiKey=${API_KEY}`;

    api.axios.get(NEWS_API_URL).then((response) => {
        let { articles } = response.data; // Access articles from response.data
        saveArticles = articles;

        p.play({ command: 'newsHendlines', articles });
        p.play(`Here are the latest ${p.source.value}.`);
        
        p.play('Would you like. me to read the headlines? ')
        p.then(confirmation);
        
    }).catch((error) => {
        saveArticles.push(error);
        p.play('Sorry, please try searching for news from a different source.');
        return;
    });
});



const confirmation = context(() => {
    intent('yes', async (p) => {
        for (let i = 0; i < saveArticles.length; i++) {
            p.play({ command: 'highlight', article: saveArticles[i] });
        
                await p.play(`${saveArticles[i].title}`);
            
        }
    });

    intent('no', (p) => {
        p.play('Sure, sounds good to me.');
    });
});
